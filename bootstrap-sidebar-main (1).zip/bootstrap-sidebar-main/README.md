
# Bootstrap 5 Sidebar

The sidebar component lets users navigate through your website. Mostly sidebars are used in admin and user panels where users must have accessibility to navigating through the webpage with ease. 

Creating these sidebar components is really easy with Bootstrap 5. So, in this video, I have implemented a sidebar component that has toggle functionality with a sidebar navigation link.

## YouTube Video Link
https://youtu.be/fFwT4vwZXhg

![Logo](https://raw.githubusercontent.com/codzsword/bootstrap-sidebar-/main/Bootstrap%20sidebar%20tutorial.png)

